
public interface ISignUp {
	public MemberVO signUp();
	public MemberVO chMyPage();
}
